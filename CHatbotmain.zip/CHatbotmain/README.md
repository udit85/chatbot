# Unity4-Chabot
IRWA assignment 2,  An intelligent chatbot and integrate with e-commerce database

# Team-Members
Mapa M.M.N.D - IT21269516
Deshapriya H.B.M.T - IT21291432 
Premathilake M.N - IT21347894
Dharmasena U D S V - IT21288326 

# Tech-Stack
Python
Tensorflow
Keras
NLTK
Flask
